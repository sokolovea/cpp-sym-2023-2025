package simple_app;

public class SimpleApp {
 
 enum Day {
     MONDAY, TUESDAY, WEDNESDAY, THURSDAY, FRIDAY, SATURDAY, SUNDAY;
 }
 
 public static String concatenate(String str1, String str2) {
     StringBuffer buffer = new StringBuffer(str1);
     buffer.append(str2);
     return buffer.toString();
 }
 
 public static void printArray(int[] array) {
     for (int num : array) {
         System.out.print(num + " ");
     }
     System.out.println();
 }
 
 public static void main(String[] args) {
     // Использование строк и строковых буферов
     String hello = "Hello, ";
     String world = "world!";
     String greeting = concatenate(hello, world);
     System.out.println(greeting);
     
     // Использование массивов
     int[] numbers = {1, 2, 3, 4, 5};
     System.out.print("Array elements: ");
     printArray(numbers);
     
     // Использование перечислений
     Day today = Day.WEDNESDAY;
     System.out.println("Today is " + today);
     
     // Преобразование перечисления в строку
     String dayString = today.toString();
     System.out.println("Today is also " + dayString);
 }
}
