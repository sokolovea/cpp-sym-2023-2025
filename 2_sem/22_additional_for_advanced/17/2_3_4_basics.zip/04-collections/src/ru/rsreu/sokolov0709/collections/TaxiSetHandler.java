package ru.rsreu.sokolov0709.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import ru.rsreu.sokolov0709.Taxi;
import ru.rsreu.sokolov0709.TaxiArrayInitializator;
import ru.rsreu.sokolov0709.enums.EnumRouteNumber;

public class TaxiSetHandler {
	private TaxiSetHandler() {
	}
	
	public static Set<Taxi> getTaxiSet() {
		Taxi[] taxiArray = TaxiArrayInitializator.initializeArray();
		Set<Taxi> taxiSet = new HashSet<Taxi>();
		Collections.addAll(taxiSet, taxiArray);
		return taxiSet;
	}
	
	public static void deleteTaxiByThirdParameter(Set<Taxi> taxiSet, EnumRouteNumber routeNumber) {
		Iterator<Taxi> iterator = taxiSet.iterator();
		while (iterator.hasNext()) {
			if (iterator.next().getRouteNumber().equals(routeNumber)) {
				iterator.remove();
			}
		}
	}
	
	public static String getStringRepresentation(Set<Taxi> taxiSet) {
		List<Taxi> taxiList = new ArrayList<Taxi>(taxiSet);
		return TaxiListHandler.getStringRepresentation(taxiList);
	}
}
