package ru.rsreu.sokolov0709;

import java.util.Iterator;
import java.util.List;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0709.enums.EnumOwnerType;

public class OutputFormatter {

	private OutputFormatter() {
	}
	
	public static String getStringTaxiTable(Iterator<Taxi> iterator) {
		StringBuffer outputString = new StringBuffer();
		outputString.append(OutputFormatter.getTableHeader());
		while (iterator.hasNext()) {
			outputString.append(iterator.next());
		}
		return outputString.toString();
	}
	
	public static String getStringEnumOwnerType(List<EnumOwnerType> ownerTypeList) {
		StringBuffer outputString = new StringBuffer();
		Iterator<EnumOwnerType> iterator = ownerTypeList.iterator();
		while (iterator.hasNext()) {
			outputString.append(iterator.next()).append("\n");
		}
		return outputString.toString();
	}
	
	public static String getTableHeader() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputString = new StringBuffer();
		outputString.append(String.format(resourcer.getString("format.table.header"), resourcer.getString("message.registrationNumber"),
				resourcer.getString("message.ownerType"), resourcer.getString("message.routeNumber")));
		return outputString.toString();
	}
	
}
