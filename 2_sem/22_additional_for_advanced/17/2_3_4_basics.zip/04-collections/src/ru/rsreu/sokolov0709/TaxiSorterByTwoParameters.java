package ru.rsreu.sokolov0709;

import java.util.Comparator;

public class TaxiSorterByTwoParameters implements Comparator<Taxi> {
	@Override
	public int compare(Taxi firstTaxi, Taxi secondTaxi) {
		int result = firstTaxi.getOwnerType().compareTo(secondTaxi.getOwnerType());
		if (result == 0) {
			result = firstTaxi.getRouteNumber().compareTo(firstTaxi.getRouteNumber());
		}
		return result;
	}
}
