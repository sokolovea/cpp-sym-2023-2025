package ru.rsreu.sokolov0709;

import java.util.List;
import java.util.Map;
import java.util.Set;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0709.collections.TaxiListHandler;
import ru.rsreu.sokolov0709.collections.TaxiMapHandler;
import ru.rsreu.sokolov0709.collections.TaxiSetHandler;
import ru.rsreu.sokolov0709.enums.EnumRouteNumber;

public class Runner {

	private Runner() {

	}
	
	public static final EnumRouteNumber DELETING_NUMBER = EnumRouteNumber.FOURTH;
	public static final int EXISTING_KEY = 5;
	public static final int NOT_EXISTING_KEY = 10;
	
	public static void main(String[] args) {

		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputString = new StringBuffer();

		List<Taxi> taxiList = TaxiListHandler.getTaxiList();
		outputString.append(resourcer.getString("message.taxiTable")).append("\n");
		outputString.append(TaxiListHandler.getStringRepresentation(taxiList)).append("\n");
		
		TaxiListHandler.defaultSort(taxiList);
		outputString.append(resourcer.getString("message.defaultSort")).append("\n");
		outputString.append(TaxiListHandler.getStringRepresentation(taxiList)).append("\n");
		
		TaxiListHandler.sortByTwoParameters(taxiList);
		outputString.append(resourcer.getString("message.sortByParameters")).append("\n");
		outputString.append(TaxiListHandler.getStringRepresentation(taxiList)).append("\n");

		outputString.append(resourcer.getString("message.secondParameterWithoutDuplication")).append("\n");
		outputString
				.append(OutputFormatter
						.getStringEnumOwnerType(TaxiListHandler.getSecondParameterListWithoutDuplication(taxiList)))
				.append("\n");

		Set<Taxi> taxiSet = TaxiSetHandler.getTaxiSet();
		TaxiSetHandler.deleteTaxiByThirdParameter(taxiSet, DELETING_NUMBER);
		outputString.append(resourcer.getString("message.deleteItemsByThirdParameter")).append(DELETING_NUMBER).append("\n")
				.append(TaxiSetHandler.getStringRepresentation(taxiSet)).append("\n");

		Map<Integer, Taxi> map = TaxiMapHandler.getTaxiMap();
		outputString.append(TaxiMapHandler.getStringResultSearchingTaxi(EXISTING_KEY, map)).append("\n");
		outputString.append(TaxiMapHandler.getStringResultSearchingTaxi(NOT_EXISTING_KEY, map));
		
		System.out.println(outputString);
	}
	


}
