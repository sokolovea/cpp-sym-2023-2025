package ru.rsreu.sokolov0709.collections;

import java.util.HashMap;
import java.util.Map;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0709.OutputFormatter;
import ru.rsreu.sokolov0709.Taxi;
import ru.rsreu.sokolov0709.TaxiArrayInitializator;

public class TaxiMapHandler {
	private TaxiMapHandler() {

	}

	public static Map<Integer, Taxi> getTaxiMap() {
		Map<Integer, Taxi> map = new HashMap<Integer, Taxi>();
		for (Taxi each : TaxiArrayInitializator.initializeArray()) {
			map.put(each.getRegistrationNumber(), each);
		}
		return map;
	}
	
	public static Taxi searchTaxiByNumber(Map<Integer, Taxi> taxiMap, int registrationNumber) {
		Taxi findTaxi;
		if (taxiMap.containsKey(registrationNumber)) {
			findTaxi = taxiMap.get(registrationNumber);
		} else {
			findTaxi = Taxi.NULL_TAXI;
		}
		return findTaxi;
	}
	
	public static String getStringResultSearchingTaxi(int searchKey, Map<Integer, Taxi> taxiMap) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputString = new StringBuffer();
		Taxi foundTaxi = TaxiMapHandler.searchTaxiByNumber(taxiMap, searchKey);
		outputString.append(resourcer.getString("message.searchByKey")).append(searchKey).append("\n");
		if (foundTaxi.isTaxiExisted()) {
			outputString.append(OutputFormatter.getTableHeader()).append(foundTaxi);
		} else {
			outputString.append(resourcer.getString("message.taxiNotFound"));
		}
		return outputString.toString();
	}
}
