package ru.rsreu.sokolov0709.collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

import ru.rsreu.sokolov0709.OutputFormatter;
import ru.rsreu.sokolov0709.Taxi;
import ru.rsreu.sokolov0709.TaxiArrayInitializator;
import ru.rsreu.sokolov0709.TaxiSorterByTwoParameters;
import ru.rsreu.sokolov0709.enums.EnumOwnerType;

public class TaxiListHandler {
	private TaxiListHandler() {
	}

	public static List<Taxi> getTaxiList() {
		Taxi[] taxiArray = TaxiArrayInitializator.initializeArray();
		List<Taxi> taxiList = new ArrayList<Taxi>();
		Collections.addAll(taxiList, taxiArray);
		return taxiList;
	}

	public static void defaultSort(List<Taxi> taxiList) {
		Collections.sort(taxiList);
	}

	public static void sortByTwoParameters(List<Taxi> taxiList) {
		Comparator<Taxi> comparator = new TaxiSorterByTwoParameters();
		Collections.sort(taxiList, comparator);
	}

	public static List<EnumOwnerType> getSecondParameterListWithoutDuplication(List<Taxi> taxiList) {
		Set<EnumOwnerType> secondParameterSet = new HashSet<EnumOwnerType>();
		Iterator<Taxi> iterator = taxiList.iterator();
		while (iterator.hasNext()) {
			secondParameterSet.add(iterator.next().getOwnerType());
		}
		List<EnumOwnerType> secondParameterList = new ArrayList<EnumOwnerType>();
		secondParameterList.addAll(secondParameterSet);
		return secondParameterList;
	}

	public static String getStringRepresentation(List<Taxi> taxiList) {
		StringBuffer outputString = new StringBuffer();
		Iterator<Taxi> iterator = taxiList.iterator();
		outputString.append(OutputFormatter.getStringTaxiTable(iterator));
		return outputString.toString();
	}
}
