package ru.rsreu.sokolov0709.enums;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public enum EnumRouteNumber {
	FIRST {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.firstRoute");
		}
	},
	SECOND {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.secondRoute");
		}
	},
	THIRD {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.thirdRoute");
		}
	},
	FOURTH {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.fourthRoute");
		}
	}
}
