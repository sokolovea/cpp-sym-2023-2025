package ru.rsreu.sokolov0609;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class TaxiArrayObject {
	private Taxi[] taxiArray;
	
	public TaxiArrayObject(Taxi[] taxiArray) {
		this.setTaxiArray(taxiArray);
	}

	public boolean isObjectExistence() {
		return !(this.getTaxiArray() == null);
	}

	public Taxi[] getTaxiArray() {
		return taxiArray;
	}
	public void setTaxiArray(Taxi[] taxiArray) {
		this.taxiArray = taxiArray;
	}
	
	@Override
	public String toString() {
		if (!this.isObjectExistence()) {
			return "";
		}
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputString = new StringBuffer();
		outputString.append(String.format(resourcer.getString("format.table.header"), resourcer.getString("message.registrationNumber"),
				resourcer.getString("message.ownerType"), resourcer.getString("message.routeNumber")));
		for (Taxi item: this.getTaxiArray()) {
			 outputString.append(item);
		}
		return outputString.toString();
	}
	
}
