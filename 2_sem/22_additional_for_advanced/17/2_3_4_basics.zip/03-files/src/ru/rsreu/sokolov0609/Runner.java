package ru.rsreu.sokolov0609;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.Scanner;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class Runner {

	private Runner() {

	}

	public static void main(String[] args) throws IOException, ClassNotFoundException, FileOrDirectoryException {
		Taxi[] taxiArray = TaxiArrayInitializator.initializeArray();
		Resourcer resourcer = ProjectResourcer.getInstance();

		File sourceDirectory = new File(resourcer.getString("files.folder.source.name"));
		File moveDirectory = new File(resourcer.getString("files.folder.move.name"));
		File copyDirectory = new File(sourceDirectory, resourcer.getString("files.folder.copy.name"));
		File preparingFile = new File(sourceDirectory,
				resourcer.getString("files.file.data.name") + "." + resourcer.getString("files.file.data.extension"));

		try {
			sourceDirectory.mkdir();
			System.out.println(resourcer.getString("files.folder") + sourceDirectory.getAbsolutePath() + " "
					+ resourcer.getString("message.created"));
			moveDirectory.mkdir();
			System.out.println(resourcer.getString("files.folder") + moveDirectory.getAbsolutePath() + " "
					+ resourcer.getString("message.created"));
			copyDirectory.mkdir();
			System.out.println(resourcer.getString("files.folder") + copyDirectory.getAbsolutePath() + " "
					+ resourcer.getString("message.created"));
			try {
				preparingFile.createNewFile();
			} catch (IOException exception) {
				throw new FileOrDirectoryException(preparingFile.getAbsolutePath(), preparingFile.getName());
			}
			System.out.println(resourcer.getString("files.file") + preparingFile.getAbsolutePath() + " "
					+ resourcer.getString("message.created"));

			FileOutputStream fileOutputStream = null;
			try {
				fileOutputStream = new FileOutputStream(preparingFile);
			} catch (Exception exception) {
				throw new FileOrDirectoryException(preparingFile.getAbsolutePath(), preparingFile.getName());
			}
			ObjectOutputStream taxiOutputStream = new ObjectOutputStream(fileOutputStream);
			for (Taxi item : taxiArray) {
				taxiOutputStream.writeObject(item);
			}
			taxiOutputStream.close();

			File backupPreparingFile = new File(copyDirectory, resourcer.getString("files.file.data.name") + "."
					+ resourcer.getString("files.file.backup.extension"));
			try {
				backupPreparingFile.createNewFile();
			} catch (IOException exception) {
				throw new FileOrDirectoryException(backupPreparingFile.getAbsolutePath(),
						backupPreparingFile.getName());
			}

			System.out.println(resourcer.getString("files.file") + backupPreparingFile.getAbsolutePath() + " "
					+ resourcer.getString("message.created"));
			TaxiFileHandler.copyFile(preparingFile, backupPreparingFile);

			File movedPreparingFile = new File(moveDirectory, resourcer.getString("files.file.data.name") + "."
					+ resourcer.getString("files.file.data.extension"));
			System.out.println(resourcer.getString("message.inputRequest"));
			Scanner in = new Scanner(System.in);
			String inputString = in.nextLine();
			in.close();
			boolean isFileMoved = false;
			if (inputString.toLowerCase().equals(resourcer.getString("message.yes"))) {
				TaxiFileHandler.moveFile(preparingFile, movedPreparingFile);
				System.out.println(resourcer.getString("files.file") + movedPreparingFile.getAbsolutePath() + " "
						+ resourcer.getString("message.created"));
				isFileMoved = true;
			}

			TaxiArrayObject taxiArrayFromBackupPreparingFile = TaxiFileHandler.readTaxiFromFile(backupPreparingFile);
			TaxiArrayObject taxiArrayFromMovedPreparingFile = null;

			if (isFileMoved) {
				taxiArrayFromMovedPreparingFile = TaxiFileHandler.readTaxiFromFile(backupPreparingFile);
			} else {
				System.out.println(resourcer.getString("message.fileIsNotMoved"));
				taxiArrayFromMovedPreparingFile = TaxiFileHandler.readTaxiFromFile(preparingFile);
			}

			if (taxiArrayFromBackupPreparingFile.isObjectExistence()) {
				taxiArrayFromBackupPreparingFile.getTaxiArray();
			}

			if (taxiArrayFromMovedPreparingFile.isObjectExistence()) {
				taxiArrayFromMovedPreparingFile.getTaxiArray();
			}

			System.out.println(resourcer.getString("message.copiedFileArray"));
			System.out.println(taxiArrayFromBackupPreparingFile.toString());
			System.out.println(resourcer.getString("message.movedFileArray"));
			System.out.println(taxiArrayFromMovedPreparingFile.toString());

			int maxArrayLength = 0;
			Taxi[] maxArray = null;
			Taxi[] minArray = null;
			if (taxiArrayFromBackupPreparingFile.getTaxiArray().length > taxiArrayFromMovedPreparingFile
					.getTaxiArray().length) {
				maxArrayLength = taxiArrayFromBackupPreparingFile.getTaxiArray().length;
				minArray = taxiArrayFromMovedPreparingFile.getTaxiArray();
				maxArray = taxiArrayFromBackupPreparingFile.getTaxiArray();
			} else {
				maxArrayLength = taxiArrayFromMovedPreparingFile.getTaxiArray().length;
				minArray = taxiArrayFromBackupPreparingFile.getTaxiArray();
				maxArray = taxiArrayFromMovedPreparingFile.getTaxiArray();
			}
			int indexCounter = 0;
			for (Taxi item : minArray) {
				System.out.print((indexCounter + 1) + " ");
				if (item.equals(maxArray[indexCounter])) {
					System.out.println(resourcer.getString("message.equivalentItem"));
				} else {
					System.out.println(resourcer.getString("message.notEquivalentItem"));
				}
				indexCounter++;
			}
			if (maxArrayLength != indexCounter) {
				System.out.println(resourcer.getString("message.notEquivalentRemainingItems"));
			}
		} catch (FileOrDirectoryException exception) {
			System.out.println(resourcer.getString("message.fileError"));
			System.out.println(exception.toString());
		}
	}

}
