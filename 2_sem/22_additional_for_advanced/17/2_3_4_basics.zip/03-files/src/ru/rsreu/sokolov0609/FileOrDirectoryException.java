package ru.rsreu.sokolov0609;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class FileOrDirectoryException extends Exception {

	/**
	 * Field serialVersionUID was added to prevent Java warning
	 */
	private static final long serialVersionUID = 1L;
	private final String path;
	private final String fileName;

	public FileOrDirectoryException(String path, String fileName) {
		this.path = path;
		this.fileName = fileName;
	}

	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputString = new StringBuffer();
		outputString.append(resourcer.getString("message.fileErrorName")).append(fileName).append("\n")
				.append(resourcer.getString("message.fileErrorPath")).append(path).append("\n");
		return outputString.toString();
	}
}
