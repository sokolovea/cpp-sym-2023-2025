package ru.rsreu.sokolov0609;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public enum EnumOwnerType {
	PRIVATE_PERSON {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.privatePerson");
		}
	},
	LEGAL_ENTITY {
		@Override
		public String toString() {
			Resourcer resourcer = ProjectResourcer.getInstance();
			return resourcer.getString("enum.legalEntity");
		}
	}
	
}
