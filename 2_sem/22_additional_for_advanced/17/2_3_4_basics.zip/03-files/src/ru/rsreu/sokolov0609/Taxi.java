package ru.rsreu.sokolov0609;

import java.io.Serializable;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class Taxi implements Comparable<Taxi>, Serializable  {
	
	/**
	 * Field serialVersionUID was added to prevent Java warning
	 */
	private static final long serialVersionUID = 1L;
	
	private int registrationNumber;
	private EnumOwnerType ownerType;
	private EnumRouteNumber routeNumber;
	
	public Taxi(int registrationNumber, EnumOwnerType ownerType, EnumRouteNumber routeNumber) {
		this.setRegistrationNumber(registrationNumber);
		this.setOwnerType(ownerType);
		this.setRouteNumber(routeNumber);
	}
	
	public EnumOwnerType getOwnerType() {
		return ownerType;
	}

	public void setOwnerType(EnumOwnerType ownerType) {
		this.ownerType = ownerType;
	}
	
	public int getRegistrationNumber() {
		return registrationNumber;
	}

	public void setRegistrationNumber(int registrationNumber) {
		this.registrationNumber = registrationNumber;
	}

	public EnumRouteNumber getRouteNumber() {
		return routeNumber;
	}

	public void setRouteNumber(EnumRouteNumber routeNumber) {
		this.routeNumber = routeNumber;
	}
	
	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		return String.format(resourcer.getString("format.table.body"), this.getRegistrationNumber(),
				this.getOwnerType().toString(), this.getRouteNumber().toString());
	}
	
	
	@Override
    public boolean equals(Object comparingObject) {
	    if (comparingObject == this) {
	        return true;
	    }
	    if (comparingObject == null || comparingObject.getClass() != this.getClass()) {
	        return false;
	    }
	    Taxi comparingTaxi = (Taxi) comparingObject;
	    return compareFields(this, comparingTaxi);
	}
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + Taxi.getFieldHashCode(this.getRegistrationNumber());
		result = prime * result + registrationNumber;
		result = prime * result + Taxi.getFieldHashCode(this.getRouteNumber());
		return result;
	}
	
	@Override
	public int compareTo(Taxi taxi) {
		return (this.getRegistrationNumber() - taxi.getRegistrationNumber());
	}
	
	private static boolean compareFields(Taxi firstObject, Taxi secondObject) {
		return ((firstObject.getRegistrationNumber() == secondObject.getRegistrationNumber())
				&& (firstObject.getOwnerType() == secondObject.getOwnerType())
				&& (firstObject.getRouteNumber() == secondObject.getRouteNumber())); 
	}
	
	private static int getFieldHashCode(Object field) {
		if (field == null) {
			return 0;
		}
		return field.hashCode();
	}
}
