package ru.rsreu.sokolov0609;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.OutputStream;

public class TaxiFileHandler {
	private TaxiFileHandler() {
	}
	
	private static boolean endOfFile(FileInputStream fileInputStream) throws IOException {
		return (fileInputStream.available() <= 0);
	}
	
	public static void copyFile(File sourceFile, File targetFile) throws FileOrDirectoryException, IOException {
		final int bufferBlockSize = 1024;
	    InputStream inputByteStream = null;
	    OutputStream outputByteStream = null;
	    try {
	    	try {
	    		inputByteStream = new FileInputStream(sourceFile);
	    	} catch (Exception exception) {
				throw new FileOrDirectoryException(sourceFile.getAbsolutePath(), sourceFile.getName());
	    	}
	    	try {
	    		outputByteStream = new FileOutputStream(targetFile);
		        byte[] readingBuffer = new byte[bufferBlockSize];
		        int length;
			        while ((length = inputByteStream.read(readingBuffer)) > 0) {
				        outputByteStream.write(readingBuffer, 0, length);
			        }
			
	    	} catch (Exception exception) {
				throw new FileOrDirectoryException(targetFile.getAbsolutePath(), targetFile.getName());
	    	}
	    } finally {
	    	try {
		    	inputByteStream.close();
		    	outputByteStream.close();
	    	} catch (Exception exception) {
	    		throw new FileOrDirectoryException(targetFile.getAbsolutePath(), targetFile.getName());
	    	}
	    }
	}
	
	public static void moveFile(File sourceFile, File targetFile) throws IOException, FileOrDirectoryException {
		TaxiFileHandler.copyFile(sourceFile, targetFile);
		sourceFile.delete();
	}
	
	public static TaxiArrayObject readTaxiFromFile(File sourceFile) throws ClassNotFoundException, IOException, FileOrDirectoryException {
		FileInputStream fileInputStream = null;
		ObjectInputStream taxiInputStream = null;
		Taxi[] taxiArray = null;
		try {
			fileInputStream = new FileInputStream(sourceFile);
			taxiInputStream = new ObjectInputStream(fileInputStream);
			int size = TaxiFileHandler.getFileSizeInTaxiObject(sourceFile);
			taxiArray = new Taxi[size];
			int currentPosition = 0;
			while (!TaxiFileHandler.endOfFile(fileInputStream)) {
				taxiArray[currentPosition] = (Taxi) taxiInputStream.readObject();
				currentPosition++;
			}
			taxiInputStream.close();
		} catch (Exception exception) {
			throw new FileOrDirectoryException(sourceFile.getAbsolutePath(), sourceFile.getName());
		}
		TaxiArrayObject taxiArrayObject = new TaxiArrayObject(taxiArray);
		
		return taxiArrayObject;
	}
	
	public static int getFileSizeInTaxiObject(File sourceFile) throws IOException, ClassNotFoundException, FileOrDirectoryException {
		FileInputStream fileInputStream = null;
		ObjectInputStream taxiInputStream = null;
		try {
			fileInputStream = new FileInputStream(sourceFile);
		} catch (IOException exception) {
			throw new FileOrDirectoryException(sourceFile.getAbsolutePath(), sourceFile.getName());
		}
		taxiInputStream = new ObjectInputStream(fileInputStream);
		int fileSize = 0;
		while (!TaxiFileHandler.endOfFile(fileInputStream)) {	
			fileSize++;
			taxiInputStream.readObject();
		}
		return fileSize;
	}
}
