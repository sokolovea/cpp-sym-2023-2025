package ru.rsreu.sokolov0609;

public class TaxiArrayInitializator {
	private TaxiArrayInitializator() {
	}
	
	public static Taxi[] initializeArray() {
		Taxi[] taxiArray = new Taxi[7];
		taxiArray[0] = new Taxi(1, EnumOwnerType.LEGAL_ENTITY, EnumRouteNumber.FIRST);
		taxiArray[1] = new Taxi(3, EnumOwnerType.PRIVATE_PERSON, EnumRouteNumber.SECOND);
		taxiArray[2] = new Taxi(2, EnumOwnerType.LEGAL_ENTITY, EnumRouteNumber.FIRST);
		taxiArray[3] = new Taxi(5, EnumOwnerType.PRIVATE_PERSON, EnumRouteNumber.FOURTH);
		taxiArray[4] = new Taxi(4, EnumOwnerType.PRIVATE_PERSON, EnumRouteNumber.SECOND);
		taxiArray[5] = new Taxi(7, EnumOwnerType.LEGAL_ENTITY, EnumRouteNumber.FOURTH);
		taxiArray[6] = new Taxi(6, EnumOwnerType.LEGAL_ENTITY, EnumRouteNumber.FOURTH);
		return taxiArray;
	}
}
