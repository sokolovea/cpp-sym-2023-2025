package ru.rsreu.sokolov0509;

import java.util.Arrays;

import ru.rsreu.sokolov0509.transport.hierarchy.AbstractTransport;
import ru.rsreu.sokolov0509.transport.hierarchy.TransportObject;

public class AviaCompany {
	private AbstractTransport[] arrayBody;
	private int maxTransportCount = 0;
	private int currentTransportCount = 0;
	
	public AviaCompany(int maxTransportCount) {
		this.setMaxTransportCount(maxTransportCount);
		this.arrayBody = new AbstractTransport[maxTransportCount];
	}

	
	private static int fixNotNegativeValue(int maxTransportCount) {
		if (maxTransportCount < 0) {
			maxTransportCount = 0;
		}
		return maxTransportCount;
	}


	public int getMaxTransportCount() {
		return maxTransportCount;
	}
	private void setMaxTransportCount(int maxTransportCount) {
		maxTransportCount = AviaCompany.fixNotNegativeValue(maxTransportCount);
		this.maxTransportCount = maxTransportCount;
	}
	public int getCurrentTransportCount() {
		return currentTransportCount;
	}
	private void setCurrentTransportCount(int currentTransportCount) {
		currentTransportCount = AviaCompany.fixNotNegativeValue(currentTransportCount);
		this.currentTransportCount = currentTransportCount;
	}
	
	private AbstractTransport[] getArrayBody() {
		return arrayBody;
	}
	
	public void appendTransport(TransportObject transport) {
		if (transport.getTransportExistenceFlague()) {
			this.getArrayBody()[this.getCurrentTransportCount()] = transport.getTransport();
			this.setCurrentTransportCount(this.getCurrentTransportCount() + 1);
		}
	}
	
	public TransportObject searchPlane(int individualNumber) {
		for (int index = 0; index < this.getCurrentTransportCount(); index++) {
			if (this.isIndividualNumberFound(index, individualNumber) && (this.getTransport(index).isThisTransportPlane())) {
				return new TransportObject(this.getTransport(index));
			}
		}
		return new TransportObject(null);
	}
	
	private boolean isIndividualNumberFound(int objectIndex, int individualNumber) {
		return (this.getTransport(objectIndex).getIndividualNumber() == individualNumber);
	}
	
	public boolean isCargoAndPassengerCapacityEnough(float cargoCapacity, int passengerCapacity) {
		return this.isCargoCapacityEnough(cargoCapacity) && this.isPassengerCapacityEnough(passengerCapacity);
	}
	
	public boolean isCargoCapacityEnough(float cargoCapacity) {
		int currentCargoCapacity = 0;
		for (int i = 0; i < this.getCurrentTransportCount(); i++) {
			currentCargoCapacity += this.getTransport(i).getCargoCapacity();
		}
		return currentCargoCapacity >= cargoCapacity;
	}
	
	public boolean isPassengerCapacityEnough(float passengerCapacity) {
		int currentPassengerCapacity = 0;
		for (int i = 0; i < this.getCurrentTransportCount(); i++) {
			currentPassengerCapacity += this.getTransport(i).getPassengerCapacity();
		}
		return (currentPassengerCapacity >= passengerCapacity);
	}
	
	private AbstractTransport[] getOnlyPlanesArray() {
		AbstractTransport[] planes = new AbstractTransport[this.getCurrentTransportCount()];
		int indexArrayPlanes = 0;
		for (int indexArrayBody = 0; indexArrayBody < this.getCurrentTransportCount(); indexArrayBody++) {
			if (this.getArrayBody()[indexArrayBody].isThisTransportPlane()) {
				planes[indexArrayPlanes] = this.getTransport(indexArrayBody);
				indexArrayPlanes++;
			}
		}
		return Arrays.copyOf(planes, indexArrayPlanes);
	}
	
	
	public void sortPlanes() {
		AbstractTransport[] planes = this.getOnlyPlanesArray();
		Arrays.sort(planes);
		int indexArrayPlanes = 0;
		for (int indexArrayBody = 0; indexArrayBody < this.getCurrentTransportCount(); indexArrayBody++) {
			if (this.getTransport(indexArrayBody).isThisTransportPlane()) {
				this.getArrayBody()[indexArrayBody] = planes[indexArrayPlanes];
				indexArrayPlanes++;
			}
		}
	}
	
	
	private AbstractTransport getTransport(int index) {
		return this.getArrayBody()[index];
	}
	
	
	@Override
	public String toString() {
		StringBuffer outputMessage = new StringBuffer();
		for (int i = 0; i < this.getCurrentTransportCount(); i++) {
			outputMessage.append(this.arrayBody[i].toString());
		}
		return outputMessage.toString();
	}

}
