package ru.rsreu.sokolov0509.transport.types;

public enum EnumTransportTypes {
	CARGO, PASSENGER
}
