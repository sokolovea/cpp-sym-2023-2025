package ru.rsreu.sokolov0509.transport.types;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class CargoTransportType extends AbstractTransportType {
	private float cargoCapacity = 0;
	
	@Override
	public final float getCargoCapacity() {
		return this.cargoCapacity;
	}
	
	@Override
	public final void setCargoCapacity(float cargoCapacity) {
		this.cargoCapacity = cargoCapacity;
	}
	
	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputMessage = new StringBuffer();
		outputMessage.append("\t").append(resourcer.getString("message.cargoType")).append("\n").append("\t")
		.append(resourcer.getString("message.cargoCapacity")).append(this.getCargoCapacity()).append(" ").append(resourcer.getString("message.tons"));
		return outputMessage.toString();
	}
	
}
