package ru.rsreu.sokolov0509.transport.hierarchy;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0509.transport.types.AbstractTransportType;
import ru.rsreu.sokolov0509.transport.types.CargoTransportType;
import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;
import ru.rsreu.sokolov0509.transport.types.PassengerTransportType;

public abstract class AbstractTransport implements Comparable<AbstractTransport> {
	
	private int invividualNumber;
	
	private int maximumFlightRange;
	
	private AbstractTransportType transportType;
	
	public AbstractTransport(EnumTransportTypes type, int maximumFlightRange) {
		if (type == EnumTransportTypes.CARGO) {
			this.transportType = new CargoTransportType();
		} else if (type == EnumTransportTypes.PASSENGER) {
			this.transportType = new PassengerTransportType();
		}
		this.setMaximumFlightRange(maximumFlightRange);
	}
	
	public abstract float getClimbRateMetersPerSecond();
	
	public float getMaxCargoCapacity() {
		return 0;
	}
	
	public float getMaxPassengerCapacity() {
		return 0;
	}
	
	public int getMaximumFlightRange() {
		return maximumFlightRange;
	}

	public void setMaximumFlightRange(int maximumFlightRange) {
		this.maximumFlightRange = maximumFlightRange;
	}

	public final void setIndividualNumber(int individualNumber) {
		this.invividualNumber = individualNumber;
	}
	
	public final int getIndividualNumber() {
		return this.invividualNumber;
	}
	
	public int getPassengerCapacity() {
		return this.transportType.getPassengerCapacity();
	}
	
	public void setPassengerCapacity(int passengerCapacity) {
		this.transportType.setPassengerCapacity(passengerCapacity);
	}
	
	public float getCargoCapacity() {
		return this.transportType.getCargoCapacity();
	}
	
	public void setCargoCapacity(float cargoCapacity) {
		this.transportType.setCargoCapacity(cargoCapacity);
	}
	
	public abstract boolean isThisTransportPlane();
	
	public abstract boolean isThisTransportHelicopter();
	
	@Override
	public int compareTo(AbstractTransport object) {
        return -(this.getMaximumFlightRange() - object.getMaximumFlightRange());
    }
	
	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputMessage = new StringBuffer();
		outputMessage.append(resourcer.getString("message.id")).append(this.getIndividualNumber()).append("\n");
		outputMessage.append("\t").append(resourcer.getString("message.maximumFlightRange"))
		.append(this.getMaximumFlightRange()).append(" ").append(resourcer.getString("message.kilometer")).append("\n");
		outputMessage.append("\t").append(resourcer.getString("message.climbRate"))
		.append(String.format("%.2f", this.getClimbRateMetersPerSecond())).append(" ")
		.append(resourcer.getString("message.metersPerSecond")).append("\n");
		outputMessage.append(this.transportType.toString()).append("\n");
		return outputMessage.toString();
	}
}
