package ru.rsreu.sokolov0509.transport.hierarchy;

import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;

public class PassengerPlane extends AbstractPlane {
	
	private final float climbRateCoefficient = 2.9f;
	
	public PassengerPlane(int individualNumber, int maximumFlightRange, int passengerCapacity) {
		super(EnumTransportTypes.PASSENGER, individualNumber, maximumFlightRange);
		this.setPassengerCapacity(passengerCapacity);
	}
	
	private float getClimbRateCoefficient() {
		return this.climbRateCoefficient;
	}
	
	@Override
	public float getClimbRateMetersPerSecond() {
		return getClimbRateCoefficient();
	}
}
