package ru.rsreu.sokolov0509.transport.hierarchy;

import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;

public class CargoPlane extends AbstractPlane {
	
	private final float climbRateCoefficient = 2.5f;
	private final float maxCargoCapacity = 8;
	
	public CargoPlane(int individualNumber, int maximumFlightRange, float cargoCapacity) {
		super(EnumTransportTypes.CARGO, individualNumber, maximumFlightRange);
		this.setCargoCapacity(cargoCapacity);
	}
	
	private float getClimbRateCoefficient() {
		return this.climbRateCoefficient;
	}
	
	@Override
	public float getClimbRateMetersPerSecond() {
		return getClimbRateCoefficient() -  this.getCargoCapacity() / (this.getMaxCargoCapacity() + this.getCargoCapacity());
	}
	
	@Override
	public float getMaxCargoCapacity() {
		return maxCargoCapacity;
	}
}
