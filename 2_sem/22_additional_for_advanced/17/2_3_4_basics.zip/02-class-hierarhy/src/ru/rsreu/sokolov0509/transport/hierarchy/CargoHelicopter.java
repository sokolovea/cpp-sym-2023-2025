package ru.rsreu.sokolov0509.transport.hierarchy;

import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;

public class CargoHelicopter extends AbstractHelicopter {
	private final float climbRateCoefficient = 0.95f;
	private final float maxCargoCapacity = 8;
	
	public CargoHelicopter(int individualNumber, int maximumFlightRange, float cargoCapacity) {
		super(EnumTransportTypes.CARGO, individualNumber, maximumFlightRange);
		this.setCargoCapacity(cargoCapacity);
	}
	
	private float getClimbRateCoefficient() {
		return this.climbRateCoefficient;
	}
	
	@Override
	public float getClimbRateMetersPerSecond() {
		return getClimbRateCoefficient() - this.getCargoCapacity() / this.getMaxCargoCapacity();
	}
	
	@Override
	public float getMaxCargoCapacity() {
		return maxCargoCapacity;
	}
}
