package ru.rsreu.sokolov0509;

import ru.rsreu.sokolov0509.transport.hierarchy.AbstractTransport;
import ru.rsreu.sokolov0509.transport.hierarchy.CargoHelicopter;
import ru.rsreu.sokolov0509.transport.hierarchy.CargoPlane;
import ru.rsreu.sokolov0509.transport.hierarchy.PassengerHelicopter;
import ru.rsreu.sokolov0509.transport.hierarchy.PassengerPlane;
import ru.rsreu.sokolov0509.transport.hierarchy.TransportObject;

public class AviaCompanyInitializator {
	private AviaCompanyInitializator() {
		
	}
	
	public static final int SEARCHING_NUMBER = 5;
	public static final int PEOPLE_COUNT_TEST = 100;
	public static final float CARGO_COUNT_TEST = 30;
	
	public static AviaCompany initializeAirport() {
		final int maxTransportCount = 50;
		final int appendingTransportCount = 10;
		AviaCompany company = new AviaCompany(maxTransportCount);
		AbstractTransport[] arrayTransport = new AbstractTransport[appendingTransportCount];
		arrayTransport[0] = new PassengerPlane(1, 4000, 75);
		arrayTransport[1] = new PassengerPlane(2, 5200, 100);
		arrayTransport[2] = new PassengerPlane(5, 3500, 85);
		arrayTransport[3] = new CargoPlane(12, 7500, 10.75f);
		arrayTransport[4] = new CargoPlane(14, 5750, 15);
		arrayTransport[5] = new PassengerPlane(3, 4250, 120);
		arrayTransport[6] = new CargoHelicopter(6, 500, 1.5f);
		arrayTransport[7] = new CargoHelicopter(12, 450, 2);
		arrayTransport[8] = new CargoHelicopter(14, 600, 2);
		arrayTransport[9] = new PassengerHelicopter(4, 500, 6);
		
		for (AbstractTransport transport: arrayTransport) {	
			company.appendTransport(new TransportObject(transport));
		}
		
		return company;
	}
}
