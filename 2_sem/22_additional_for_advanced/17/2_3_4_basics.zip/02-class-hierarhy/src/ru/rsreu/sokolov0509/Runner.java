package ru.rsreu.sokolov0509;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0509.transport.hierarchy.TransportObject;

public class Runner {

	private Runner() {

	}

	public static void main(String[] args) {
		Resourcer resourcer = ProjectResourcer.getInstance();
		AviaCompany company = AviaCompanyInitializator.initializeAirport();
		StringBuffer outputMessage = new StringBuffer();
		outputMessage.append(resourcer.getString("message.creatingCompany"))
		.append(company.getCurrentTransportCount()).append(" ").append(resourcer.getString("message.objects")).append("\n");
		outputMessage.append(company.toString());
		company.sortPlanes();
		outputMessage.append(resourcer.getString("message.sorting"));
		outputMessage.append(company.toString());
		outputMessage.append(resourcer.getString("message.beforeFinding")).append(AviaCompanyInitializator.SEARCHING_NUMBER).append("\n");
		TransportObject foundingPlane = company.searchPlane(AviaCompanyInitializator.SEARCHING_NUMBER);
		if (Runner.isTransportExistence(foundingPlane)) {
			outputMessage.append(resourcer.getString("message.found")).append("\n").append(foundingPlane.getTransport().toString()).append("\n");
		} else {
			outputMessage.append(resourcer.getString("message.notFound")).append("\n");
		}
		outputMessage.append((resourcer.getString("message.checkCargoAndPassenger"))).append("\n");
		outputMessage.append(resourcer.getString("message.peopleCount")).append(AviaCompanyInitializator.PEOPLE_COUNT_TEST).append("\n");
		outputMessage.append(resourcer.getString("message.cargoCount")).append(AviaCompanyInitializator.CARGO_COUNT_TEST).append("\n");
		outputMessage.append(resourcer.getString("message.capacity")).append(" ");
		if (company.isCargoAndPassengerCapacityEnough(AviaCompanyInitializator.CARGO_COUNT_TEST, AviaCompanyInitializator.PEOPLE_COUNT_TEST)) {
			outputMessage.append(resourcer.getString("message.positiveCheckCapacity"));
		} else {
			outputMessage.append(resourcer.getString("message.negativeChackCapacity"));
		}
		System.out.print(outputMessage);
	}
	
	public static boolean isTransportExistence(TransportObject transport) {
		return transport.getTransportExistenceFlague();
	}

}
