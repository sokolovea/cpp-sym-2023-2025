package ru.rsreu.sokolov0509.transport.types;

public abstract class AbstractTransportType {
	
	public int getPassengerCapacity() {
		return 0;
	}
	
	public void setPassengerCapacity(int passengerCapacity) {
	}
	
	public float getCargoCapacity() {
		return 0;
	}
	
	public void setCargoCapacity(float cargoCapacity) {
	}

	@Override
	public abstract String toString();
	
	
}
