package ru.rsreu.sokolov0509.transport.hierarchy;

public class TransportObject {
	
	private AbstractTransport transport;
	
	public TransportObject(AbstractTransport transport) {
		this.setTransport(transport);
	}
	
	public boolean getTransportExistenceFlague() {
		return (this.getTransport() != null); 
	}

	public final AbstractTransport getTransport() {
		return transport;
	}
	private void setTransport(AbstractTransport transport) {
		this.transport = transport;
	}
}
