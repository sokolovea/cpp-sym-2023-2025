package ru.rsreu.sokolov0509.transport.hierarchy;

import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;

public class PassengerHelicopter extends AbstractHelicopter {
	
	private final float climbRateCoefficient = 1.1f;
	
	public PassengerHelicopter(int individualNumber, int maximumFlightRange, int passengerCapacity) {
		super(EnumTransportTypes.PASSENGER, individualNumber, maximumFlightRange);
		this.setPassengerCapacity(passengerCapacity);
	}
	
	private float getClimbRateCoefficient() {
		return this.climbRateCoefficient;
	}
	
	@Override
	public float getClimbRateMetersPerSecond() {
		return getClimbRateCoefficient();
	}
}
