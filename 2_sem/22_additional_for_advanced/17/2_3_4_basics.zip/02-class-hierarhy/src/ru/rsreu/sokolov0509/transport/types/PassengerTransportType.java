package ru.rsreu.sokolov0509.transport.types;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

public class PassengerTransportType extends AbstractTransportType {
	private int passengerCapacity = 0;
	
	@Override
	public final int getPassengerCapacity() {
		return this.passengerCapacity;
	}
	
	@Override
	public final void setPassengerCapacity(int passengerCapacity) {
		this.passengerCapacity = passengerCapacity;
	}
	
	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputMessage = new StringBuffer();
		outputMessage.append("\t").append(resourcer.getString("message.passengerType"))
		.append("\n").append("\t").append(resourcer.getString("message.passengerCapacity"))
		.append(this.getPassengerCapacity()).append(" ").append(resourcer.getString("message.people"));
		return outputMessage.toString();
	}

}
