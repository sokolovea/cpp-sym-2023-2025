package ru.rsreu.sokolov0509.transport.hierarchy;

import com.prutzkow.resourcer.ProjectResourcer;
import com.prutzkow.resourcer.Resourcer;

import ru.rsreu.sokolov0509.transport.types.EnumTransportTypes;

public abstract class AbstractHelicopter extends AbstractTransport {
	
	private final float maxCargoCapacity = 7;
	
	public AbstractHelicopter(EnumTransportTypes type, int individualNumber, int maximumFlightRange) {
		super(type, maximumFlightRange);
		super.setIndividualNumber(individualNumber);
	}
	
	
	@Override
	public boolean isThisTransportPlane() {
		return false;
	}

	@Override
	public boolean isThisTransportHelicopter() {
		return true;
	}
	
	@Override
	public String toString() {
		Resourcer resourcer = ProjectResourcer.getInstance();
		StringBuffer outputMessage = new StringBuffer();
		outputMessage.append(resourcer.getString("message.helicopter")).append("\n");
		outputMessage.append(super.toString());
		return outputMessage.toString();
	}


	public float getMaxCargoCapacity() {
		return maxCargoCapacity;
	}
}
